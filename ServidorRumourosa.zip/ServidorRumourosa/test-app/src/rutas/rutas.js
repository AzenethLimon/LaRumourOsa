const { Router } = require('express');
const router = Router();

const datos = require('./datosRumorosa.json');
console.log(datos);

//RUTAS DATOS
router.get('/',(req,res) =>{
    res.json(datos);
});

//RUTAS USUARIOS
router.get('/usuarios', (req,res) => {
res.json(datos["Datos de usuario"]);
});

router.get('/usuarios/:id', (req,res) => {
    const {id} = req.params;
    datos["Datos de usuario"].forEach(dato =>{
        if(dato.ID_de_Usuario == id){
            res.json(dato);
        }
    });
    console.log(id);
});

router.post('/usuarios', (req,res) => {
    const{Nombre_de_usuario,Correo_electrónico,Contraseña,Fecha_de_registro} = req.body;
    if(Nombre_de_usuario && Correo_electrónico && Contraseña && Fecha_de_registro){
        const ID_de_Usuario = datos["Datos de usuario"].length +1;
        const nuevoUsuario = {...req.body, ID_de_Usuario};
        datos["Datos de usuario"].push(nuevoUsuario);
        console.log(nuevoUsuario);
        res.send(datos);
    }else{
        res.status(500).json({error: 'no data'});
        }
});

router.delete('/usuarios/:id', (req,res) => {
    const { id } = req.params;
    const index = datos["Datos de usuario"].findIndex(dato => dato.ID_de_Usuario == id);
    
    if (index !== -1) {
        const borrarUser = datos["Datos de usuario"].splice(index, 1);
        console.log(`Usuario eliminado: ${borrarUser}`);
        res.json({ message: 'Usuario eliminado correctamente', borrarUser });
    } else {
        res.status(404).json({ error: 'Usuario no encontrado' });
}
});

//RUTAS PUBLICACIONES
router.get('/publicaciones', (req,res) => {
    res.json(datos["Publicaciones"]);
});

router.post('/publicaciones', (req,res) => {
    const{ID_de_Usuario,Tipo_de_publicación,Fecha_de_publicación,Etiquetas} = req.body;
    if(ID_de_Usuario && Tipo_de_publicación && Fecha_de_publicación && Etiquetas){
        const IDdePublicación = datos["Publicaciones"].length +1;
        const nuevaPub = {...req.body, IDdePublicación};
        datos["Publicaciones"].push(nuevaPub);
        console.log(nuevaPub);
        res.send(datos);
    }else{
        res.status(500).json({error: 'no data'});
        }
});
//RUTAS LIKES
router.get('/likes', (req,res) => {
    res.json(datos["Me gusta"]);
});

router.post('/likes', (req,res) => {
    const{ID_de_Usuario,IDdePublicación} = req.body;
    if(ID_de_Usuario && IDdePublicación){
        const ID_de_Like = datos["Me gusta"].length +1;
        const like = {...req.body, ID_de_Like};
        datos["Me gusta"].push(like);
        console.log(like);
        res.send(datos);
    }else{
        res.status(500).json({error: 'no data'});
        }
});
//RUTAS COMENTARIOS
router.get('/comentarios', (req,res) => {
    res.json(datos["Comentarios"]);
});

router.post('/comentarios', (req,res) => {
    const{ID_de_Usuario,IDdePublicación,Fecha_de_Comentario} = req.body;
    if(ID_de_Usuario && IDdePublicación && Fecha_de_Comentario){
        const ID_de_Comentario = datos["Comentarios"].length +1;
        const comentario = {...req.body, ID_de_Comentario};
        datos["Comentarios"].push(comentario);
        console.log(comentario);
        res.send(datos);
    }else{
        res.status(500).json({error: 'no data'});
        }
});

module.exports = router;