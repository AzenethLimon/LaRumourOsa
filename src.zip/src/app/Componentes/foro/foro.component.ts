import { Component } from '@angular/core';

@Component({
  selector: 'app-foro',
  standalone: true,
  imports: [],
  templateUrl: './foro.component.html',
  styleUrl: './foro.component.css'
})
export class ForoComponent {

}
