import { Component } from '@angular/core';

@Component({
  selector: 'app-reglamento',
  standalone: true,
  imports: [],
  templateUrl: './reglamento.component.html',
  styleUrl: './reglamento.component.css'
})
export class ReglamentoComponent {

}
