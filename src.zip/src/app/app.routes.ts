import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomePageComponent } from './Componentes/home-page/home-page.component';
import { BlogsComponent } from './Componentes/blogs/blogs.component';
import { CrearCuentaComponent } from './Componentes/crear-cuenta/crear-cuenta.component';
import { InicioSesionComponent } from './Componentes/inicio-sesion/inicio-sesion.component';
import { ForoComponent } from './Componentes/foro/foro.component';
import { NoticiasComponent } from './Componentes/noticias/noticias.component';
import { MiPerfilComponent } from './Componentes/mi-perfil/mi-perfil.component';
import { FAQComponent } from './Componentes/faq/faq.component';
import { PoliticasComponent } from './Componentes/politicas/politicas.component';
import { ReglamentoComponent } from './Componentes/reglamento/reglamento.component';

export const routes: Routes = [
{path: '', component : HomePageComponent},
{path: 'blogs', component : BlogsComponent},
{path: 'signin', component : CrearCuentaComponent},
{path: 'login', component : InicioSesionComponent},
{path: 'foro', component : ForoComponent},
{path: 'noticias', component : NoticiasComponent},
{path: 'profile', component : MiPerfilComponent},
{path: 'faq', component: FAQComponent},
{path: 'politicas', component: PoliticasComponent},
{path: 'reglamento', component: ReglamentoComponent}
];

@NgModule({
    imports: [ RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutes{}
