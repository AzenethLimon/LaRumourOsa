import { Component } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';

import { HomePageComponent } from './Componentes/home-page/home-page.component';
import { HeaderComponent } from './Componentes/header/header.component';
import { FooterComponent } from './Componentes/footer/footer.component';
import { BlogsComponent } from './Componentes/blogs/blogs.component';
import { CrearCuentaComponent } from './Componentes/crear-cuenta/crear-cuenta.component';
import { InicioSesionComponent } from './Componentes/inicio-sesion/inicio-sesion.component';
import { ForoComponent } from './Componentes/foro/foro.component';
import { NoticiasComponent } from './Componentes/noticias/noticias.component';
import { MiPerfilComponent } from './Componentes/mi-perfil/mi-perfil.component';
import { FAQComponent } from './Componentes/faq/faq.component';
import { PoliticasComponent } from './Componentes/politicas/politicas.component';
import { ReglamentoComponent } from './Componentes/reglamento/reglamento.component';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterLink, RouterOutlet, FooterComponent, HeaderComponent, HomePageComponent, BlogsComponent, CrearCuentaComponent, InicioSesionComponent, ForoComponent, NoticiasComponent, MiPerfilComponent, FAQComponent, PoliticasComponent, ReglamentoComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'DIFER';
}
