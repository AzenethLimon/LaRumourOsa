import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { HeaderComponent } from './Componentes/header/header.component';
import { HomePageComponent } from './Componentes/home-page/home-page.component';
import { FooterComponent } from './Componentes/footer/footer.component';
import { BlogsComponent } from './Componentes/blogs/blogs.component';
import { ForoComponent } from './Componentes/forum/forum.component';
import { FAQComponent } from './Componentes/faq/faq.component';
import { CrearCuentaComponent } from './Componentes/crear-cuenta/crear-cuenta.component';
import { PoliticasComponent } from './Componentes/politicas/politicas.component';
import { ReglamentoComponent } from './Componentes/reglamento/reglamento.component';

NgModule({
    declarations: [
        RouterModule,
        AppComponent,
        HeaderComponent,
        HomePageComponent,
        FooterComponent,
        BlogsComponent,
        CrearCuentaComponent,
        ForoComponent,
        FAQComponent,
        CrearCuentaComponent,
        PoliticasComponent,
        ReglamentoComponent
    ],


    exports: [
        BrowserModule,
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }